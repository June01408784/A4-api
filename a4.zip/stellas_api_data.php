<?php

// kvstore API url
$url = 'https://billboard-api2.p.rapidapi.com/hot-100?range=1-10&date=2019-05-11';


// Initializes a new cURL session
$curl = curl_init($url);

// Set the CURLOPT_RETURNTRANSFER option to true
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

// Set custom headers for RapidAPI Auth and Content-Type header
curl_setopt($curl, CURLOPT_HTTPHEADER, [
  'X-RapidAPI-Host: billboard-api2.p.rapidapi.com',
  'X-RapidAPI-Key: a027abf25amshd3940f8f389005bp118522jsn342cc9c5eec0'
]);

// Execute cURL request with all previous settings
$response = curl_exec($curl);

// Close cURL session
curl_close($curl);

echo $response . PHP_EOL;