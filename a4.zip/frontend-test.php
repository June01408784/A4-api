<?php

include( 'admin/includes/database.php' );

?>

<!doctype html>
<html>
  <head>
  
      <link href="front.css" type="text/css" rel="stylesheet">

      <title>House List</title>
  </head>
  <body>

    <h1>Stay In Toronto</h1>
  
  <?php


  $query = 'SELECT *
    FROM projects
    ORDER BY fromDate DESC';
  $result = mysqli_query( $connect, $query );

  // include 'admin/includes/wideimage/WideImage.php';

  ?>

    <div class= "container">
    <?php while( $record = mysqli_fetch_assoc( $result ) ): ?>
     
        <!-- Property List -->
        <div class="item">
        <!-- <img src="admin/image.php?type=project&id=<?php echo $record['id']; ?>&width=500&height=500&format=inside"> -->
        <h2><?php echo htmlentities( $record['property'] ); ?></h2>
        <p>Type: <?php echo $record['type']; ?></p>
      

        <a href="property.php?id=<?php echo $record['id']; ?>">View More Details</a>
    
      <!-- Item div end -->
      </div>
        
    <?php endwhile; ?>

    <!-- Container div end -->
        </div> 

  </body>
</html>
