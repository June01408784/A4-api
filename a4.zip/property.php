<?php

include( 'admin/includes/database.php' );

?>

<!doctype html>
<html>
  <head>
  <title>Property Details</title>
<style>

h1 {
  font-family: sans-serif;
  padding-top: 30px;
  padding-bottom: 40px;
  border-bottom: 1px solid #dbdbdb;
  text-align: center;
  font-size:24px;
}

.content {
  display: grid;
  grid-template-columns: auto auto;
  font-family: sans-serif;
  padding-left: 100px;
  padding-right: 100px;
  grid-gap: 20px;
}

.item {
    padding: 20px;
    border: 1px solid #7F56D9;
    border-radius: 20px;
    box-shadow: 5px 4px 4px #dadada;
}

.item img {
  justify-self: center;
}

.item-b {
  padding-left: 100px;
  border: 1px solid #7F56D9;
  box-shadow: 5px 4px 4px #dadada;
  border-radius: 20px;
  place-self: center stretch;
}

.item img {
  width: 600px;
  height: 400px;
  object-fit: cover;
}

.title {
  font-weight: 700;
  margin: 0;
  padding-bottom: 5px;
}

.info {
  margin: 0;
  padding-bottom: 20px;
  font-weight: 200;
}

</style>
  
</head>
  <body>

    <h1>Property Details</h1>
  
   
  <?php


  $query = 'SELECT *
    FROM projects
    WHERE id ='.$_GET['id'];
  $result = mysqli_query( $connect, $query );



?>
    
    <?php while( $record = mysqli_fetch_assoc( $result ) ): ?>
      
      <div class="content">
        <div class="item">
        <img src="admin/image.php?type=project&id=<?php echo $record['id']; ?>&width=600&height=600&format=inside">
       
        <!-- house div for img end   -->
        </div> 

        <div class="item">
        <h2><?php echo htmlentities( $record['property'] ); ?></h2>
        <p><?php echo $record['content']; ?></p>
        <p class="title">Type: </p>
        <p class="info"><?php echo $record['type']; ?></p>
        <p class="title">From Date: </p>
        <p class="info"><?php echo htmlentities ($record['fromDate'] ); ?></p>
        <p class="title">To Date: </p>
        <p class="info"><?php echo htmlentities ($record['toDate'] ); ?></p>
        </div> 

        <?php

        $query2 = 'SELECT *
        FROM agents
        WHERE projects_id = '.$record['id'].'
        ORDER BY name DESC';
        $result2 = mysqli_query( $connect, $query2 );

        ?>

        <?php while( $record2 = mysqli_fetch_assoc( $result2 ) ): ?> 
          <div class="item-b">
            <h2>Host</h2>
            <img style= "border-radius: 50px;" src="admin/image.php?type=agents&id=<?php echo $record2['id']; ?>&width=100&height=100&format=inside">
            <p class="title"><?php echo $record2['name']; ?></p>
            <p class="title">Contact Number: </p>
            <p class="info"><?php echo $record2['phone']; ?></p>
          
        <!-- item-b div end -->
          </div> 


        <?php endwhile; ?>
        
        
      <?php endwhile; ?>

      <!-- Content div end -->
      </div>

      



  </body>
</html>
