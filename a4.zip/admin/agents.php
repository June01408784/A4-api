<?php

include( 'includes/database.php' );
include( 'includes/config.php' );
include( 'includes/functions.php' );

secure();

include( 'includes/header.php' );

if( isset( $_GET['delete'] ) )
{
  
  $query = 'DELETE FROM agents
    WHERE id = '.$_GET['delete'].'
    LIMIT 1';
  mysqli_query( $connect, $query );
    
  set_message( 'Host has been deleted' );
  
  header( 'Location: agents.php' );
  die();
  
}

$query = 'SELECT agents.id,
  agents.profile,
  agents.name,
  agents.phone,
  projects.property AS projects
  FROM agents
  LEFT JOIN projects
  ON agents.projects_id = projects.id
  ORDER BY name DESC';

$result = mysqli_query( $connect, $query );

include 'includes/wideimage/WideImage.php';

?>

<h2>Manage Hosts</h2>

<table>
  <tr>
    <th></th>
    <th align="center">ID</th>
    <th align="left">Name</th>
    <th align="left">Contact Number</th>
    <th align="left">Property Name</th>
    <th></th>
    <th></th>
    <th></th>
  </tr>
  <?php while( $record = mysqli_fetch_assoc( $result ) ): ?>
    <tr>
      <td align="center">
        <!-- <img src="<?php echo $record['profile'];?>"> -->
        <img src="image.php?type=agents&id=<?php echo $record['id']; ?>&width=100&height=100&format=inside">
      </td>
      <td align="center"><?php echo $record['id']; ?></td>
      <td align="left">
        <?php echo htmlentities( $record['name'] ); ?>
      </td>
      <td align="center">
        <?php echo htmlentities( $record['phone'] ); ?>
      </td>
      <td align="center">
        <?php echo htmlentities( $record['projects'] ); ?>
      </td>
      <td align="center"><a href="agents_profile.php?id=<?php echo $record['id']; ?>">Profile Photo</i></a></td>
      <td align="center"><a href="agents_edit.php?id=<?php echo $record['id']; ?>">Edit</i></a></td>
      <td align="center">
        <a href="agents.php?delete=<?php echo $record['id']; ?>" onclick="javascript:confirm('Are you sure you want to delete this host?');">Delete</i></a>
      </td>
    </tr>
  <?php endwhile; ?>
</table>

<p><a href="agents_add.php"><i class="fas fa-plus-square"></i> Add Hosts</a></p>


<?php

include( 'includes/footer.php' );

?>