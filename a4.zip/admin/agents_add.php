<?php

include( 'includes/database.php' );
include( 'includes/config.php' );
include( 'includes/functions.php' );

secure();

include( 'includes/header.php' );

if( isset( $_POST['name'] ) )
{
  
  if( $_POST['name'] )
  {
    
    $query = 'INSERT INTO agents (
        name,
        phone,
        projects_id
      ) VALUES (
         "'.mysqli_real_escape_string( $connect, $_POST['name'] ).'",
         "'.mysqli_real_escape_string( $connect, $_POST['phone'] ).'",
         "'.mysqli_real_escape_string( $connect, $_POST['projects_id'] ).'"
      )';


    mysqli_query( $connect, $query );
    
    set_message( 'Host has been added' );
    
  }
  
  header( 'Location: agents.php' );
  die();
  
}

?>

<h2>Add Hosts</h2>

<form method="post">
  
  <label for="name">Host Name:</label>
  <input type="text" name="name" id="name">
    
  <br>

  <label for="phone">Contact number:</label>
  <input type="text" name="phone" id="phone">

  <br>
  
  <label for="projects_id">Property Name:</label>
  <?php

  $query = 'SELECT *
    FROM projects
    ORDER BY fromDate DESC';
  $result = mysqli_query( $connect, $query );
  
  echo '<select name="projects_id" id="projects_id">';
  while( $record = mysqli_fetch_assoc( $result ) )
  {
    echo '<option value="'.$record['id'].'"';
    echo '>'.$record['property'].'</option>';
  }
  echo '</select>';
  
  ?>

  <br>
  
  <input type="submit" value="Add Host">
  
</form>

<p><a href="agents.php"><i class="fas fa-arrow-circle-left"></i> Return to Hosts List</a></p>


<?php

include( 'includes/footer.php' );

?>