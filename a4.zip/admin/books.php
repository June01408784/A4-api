<?php

include( 'includes/database.php' );
include( 'includes/config.php' );
include( 'includes/functions.php' );

secure();

include( 'includes/header.php' );

if( isset( $_GET['delete'] ) )
{
  
  $query = 'DELETE FROM billboard
    WHERE id = '.$_GET['delete'].'
    LIMIT 1';
  mysqli_query( $connect, $query );
    
  set_message( 'Song has been deleted' );
  
  header( 'Location: books.php' );
  die();
  
}

$query = 'SELECT *
  FROM billboard
  ORDER BY title DESC';
$result = mysqli_query( $connect, $query );

?>

<h2>Top 10 Billboard Songs</h2>

<table>
  <tr>
    <th align="left">ID</th>
    <th align="left">Title</th>
    <th align="left">Rank</th>
    <th align="left">Artist</th>
  </tr>

  <?php while( $record = mysqli_fetch_assoc( $result ) ): ?>
    <tr>
      <td align="left"><?php echo $record['id']; ?></td>
      <td align="left">
        <?php echo htmlentities( $record['title'] ); ?>
      </td>
      <td align="left">
        <?php echo htmlentities( $record['rank'] ); ?>
      </td>
      <td align="left">
        <?php echo htmlentities( $record['artist'] ); ?>
      </td>
      <td align="center">
        <a href="books.php?delete=<?php echo $record['id']; ?>" onclick="javascript:confirm('Are you sure you want to delete this song?');">Delete</i></a>
      </td>
    </tr>
  <?php endwhile; ?>
</table>

<p><a href="books_import.php"><i class="fas fa-plus-square"></i>Import Song</a></p>


<?php

include( 'includes/footer.php' );

?>