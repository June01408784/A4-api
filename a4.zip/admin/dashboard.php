<?php

include( 'includes/database.php' );
include( 'includes/config.php' );
include( 'includes/functions.php' );

secure();

include( 'includes/header.php' );

?>

<ul id="dashboard">
<!-- add a user button  -->
  <li>
    <a href="projects.php">
      &#127968 Manage Projects
    </a>
  </li>
  <li>
    <a href="agents.php">
      &#129312 Manage Host
    </a>
  </li>
  <li>
    <a href="users.php">
      &#129302 Account
    </a>
  </li>
  <li>
    <a href="books.php">
      Manage Books
    </a>
  </li>
  <li>
    <a href="books_import.php">
      Import a Book
    </a>
  </li>
  <li>
    <a href="books_export.php">
      Export Books JSON
    </a>
  </li>
</ul>

<?php

include( 'includes/footer.php' );

?>
