<?php

include( 'includes/database.php' );
include( 'includes/config.php' );
include( 'includes/functions.php' );

secure();

include( 'includes/header.php' );

if( !isset( $_GET['id'] ) )
{
  
  header( 'Location: agents.php' );
  die();
  
}

if( isset( $_FILES['profile'] ) )
{
  
  if( isset( $_FILES['profile'] ) )
  {
  
    if( $_FILES['profile']['error'] == 0 )
    {

      switch( $_FILES['profile']['type'] )
      {
        case 'image/png': 
          $type = 'png'; 
          break;
        case 'image/jpg':
        case 'image/jpeg':
          $type = 'jpeg'; 
          break;
        case 'image/gif': 
          $type = 'gif'; 
          break;      
      }

      $query = 'UPDATE agents SET
        profile = "data:image/'.$type.';base64,'.base64_encode( file_get_contents( $_FILES['profile']['tmp_name'] ) ).'"
        WHERE id = '.$_GET['id'].'
        LIMIT 1';
      mysqli_query( $connect, $query );

    }
    
  }
  
  set_message( 'Profile photo has been updated' );

  header( 'Location: agents.php' );
  die();
  
}


if( isset( $_GET['id'] ) )
{
  
  if( isset( $_GET['delete'] ) )
  {
    
    $query = 'UPDATE agents SET
      profile = ""
      WHERE id = '.$_GET['id'].'
      LIMIT 1';
    $result = mysqli_query( $connect, $query );
    
    set_message( 'Host profile photo has been deleted' );
    
    header( 'Location: agents.php' );
    die();
    
  }
  
  $query = 'SELECT *
    FROM agents
    WHERE id = '.$_GET['id'].'
    LIMIT 1';
  $result = mysqli_query( $connect, $query );
  
  if( !mysqli_num_rows( $result ) )
  {
    
    header( 'Location: agents.php' );
    die();
    
  }
  
  $record = mysqli_fetch_assoc( $result );
  
}

include 'includes/wideimage/WideImage.php';

?>

<h2>Edit Host Profile Photo</h2>

<p>
  Note: For best results, photos should be approximately 800 x 800 pixels.
</p>

<?php if( $record['photo'] ): ?>

  <?php

  $data = base64_decode( explode( ',', $record['profile'] )[1] );
  $img = WideImage::loadFromString( $data );
  $data = $img->resize( 200, 200, 'outside' )->crop( 'center', 'center', 200, 200 )->asString( 'jpg', 70 );

  ?>
  <p><img src="data:image/jpg;base64,<?php echo base64_encode( $data ); ?>" width="200" height="200"></p>
  <p><a href="agents_profile.php?id=<?php echo $_GET['id']; ?>&delete"><i class="fas fa-trash-alt"></i> Delete this Photo</a></p>

<?php endif; ?>

<form method="post" enctype="multipart/form-data">
  
  <label for="profile">Profile Photo:</label>
  <input type="file" name="profile" id="profile">
  
  <br>
  
  <input type="submit" value="Save Profile">
  
</form>

<p><a href="agents.php"><i class="fas fa-arrow-circle-left"></i> Return to Hosts List</a></p>


<?php

include( 'includes/footer.php' );

?>