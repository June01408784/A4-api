<?php

$connect = mysqli_connect( 
    "localhost", // Host
    "a4_api", // Username
    "password", // Password
    "a4_api" // Database name
);

mysqli_set_charset( $connect, 'UTF8' );
