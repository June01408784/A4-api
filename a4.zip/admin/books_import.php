<?php

include( 'includes/database.php' );
include( 'includes/config.php' );
include( 'includes/functions.php' );

secure();

include( 'includes/header.php' );

// ------- STEP 1. ------- 

// June's X-RapidAPI-Key
$key = 'a027abf25amshd3940f8f389005bp118522jsn342cc9c5eec0';

if( isset( $_GET['id'] ) )
{
    // kvstore API url
    $url = 'https://billboard-api2.p.rapidapi.com/hot-100?range=1-10&date=2019-05-11'.$_GET['id'].'?key='.$key;
    // Innitialize new cURL session
    $ch = curl_init();
    // Set the CURLOPT_RETURNTRANSFER option to true
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_URL, $url);
    // Execute cURL request w/ all previous settings
    $result = curl_exec($ch);
    // Close cURL session
    curl_close($ch);

    $data = json_decode($result, true);

    die();

    // -------  STEP 2. ------- 
    
    $query = 'INSERT INTO billboard (
            title,
            rank,
            artist,
            id
        ) VALUES (
            "'.mysqli_real_escape_string( $connect, $data['content']['title'] ).'",
            "'.mysqli_real_escape_string( $connect, $data['content']['rank'] ).'",
            "'.mysqli_real_escape_string( $connect, $data['content']['artist'] ).'",
            "'.mysqli_real_escape_string( $connect, $data['id'] ).'"
        )';
    mysqli_query( $connect, $query );

  set_message( 'Song has been added' );
  
  header( 'Location: books.php' );
  die();
  
}

?>

<!-- --------------------------------- -->

<h2>Import a Song</h2>

<form method="get">
  
  <label for="keywords">Keywords: </label>
  <input type="text" name="keywords" id="keywords">
    
  <br>
  
  <input type="submit" value="Search">
  
</form>

<?php

if(isset($_GET['keywords']))
{

    $keywords = str_replace(' ', '+', $_GET['keywords']);

    $url = 'https://billboard-api2.p.rapidapi.com/hot-100?range=1-10&date=2019-05-11'.$keywords.'&key='.$key;

    // Initializes a new cURL session
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_URL, $url);
    $result = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($result, true);

    // Create new variable to retrieve data (title, rank, artist) from 'info' section in the api
    $songs = $data['info'];

    for($i = 0; $i < count($songs); $i ++)
    {

        echo '<h2>'.$songs[$i]['content']['title'].'</h2>';
        echo '<p>Rank: '.$songs[$i]['content']['rank'].'</p>';
        echo '<p>Artist: '.$songs[$i]['content']['artist'].'</p>';
        echo '<a href="books_import.php?id='.$songs[$i]['id'].'">Import Song</a>';
        echo '<hr>';

    }

    /*
    echo '<pre>';
    print_r($data);
    echo '</pre>';
    */

}

?>

<p><a href="books.php"><i class="fas fa-arrow-circle-left"></i> Return to Billboard</a></p>


<?php

include( 'includes/footer.php' );

?>