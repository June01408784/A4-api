<?php

include( 'includes/database.php' );
include( 'includes/config.php' );
include( 'includes/functions.php' );

secure();

include( 'includes/header.php' );

if( !isset( $_GET['id'] ) )
{
  
  header( 'Location: agents.php' );
  die();
  
}

if( isset( $_POST['name'] ) )
{
  
  if( $_POST['name'])
  {
    
    $query = 'UPDATE agents SET
      name = "'.mysqli_real_escape_string( $connect, $_POST['name'] ).'",
      phone = "'.mysqli_real_escape_string( $connect, $_POST['phone'] ).'",
      projects_id = "'.mysqli_real_escape_string( $connect, $_POST['projects_id'] ).'"
      WHERE id = '.$_GET['id'].'
      LIMIT 1';
    mysqli_query( $connect, $query );
    
    set_message( 'Host has been updated' );
    
  }

  header( 'Location: agents.php' );
  die();
  
}


if( isset( $_GET['id'] ) )
{
  
  $query = 'SELECT *
    FROM agents
    WHERE id = '.$_GET['id'].'
    LIMIT 1';
  $result = mysqli_query( $connect, $query );
  
  if( !mysqli_num_rows( $result ) )
  {
    
    header( 'Location: agents.php' );
    die();
    
  }
  
  $record = mysqli_fetch_assoc( $result );
  
}

?>

<h2>Edit Host</h2>

<form method="post">
  
  <label for="property">Host Name:</label>
  <input type="text" name="name" id="name" value="<?php echo htmlentities( $record['name'] ); ?>">
    
  <br>
  
  <label for="phone">Contact Number:</label>
  <input type="text" name="phone" id="phone" value="<?php echo htmlentities( $record['phone'] ); ?>">
    
  <br>
    <!-- if( $value == $record['type'] ) echo ' selected="selected"';
  -->

  <label for="projects_id">Property Name:</label>
  <?php

  $query = 'SELECT *
    FROM projects
    ORDER BY id DESC';
  $result = mysqli_query( $connect, $query );
  
  echo '<select name="projects_id" id="projects_id">';
  while( $record2 = mysqli_fetch_assoc( $result ) )
  {
    echo '<option value="'.$record2['id'].'"';
    if( $record['projects_id'] == $record2['id'] ) echo ' selected="selected"';
    echo '>'.$record2['property'].'</option>';
  }
  echo '</select>';
  
  ?>

  <br>
  
  <br>
  
  <input type="submit" value="Edit agents">
  
</form>

<p><a href="agents.php"><i class="fas fa-arrow-circle-left"></i> Return to Hosts List</a></p>


<?php

include( 'includes/footer.php' );

?>